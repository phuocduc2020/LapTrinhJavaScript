var File = require("fs")
var Duong_dan_xu_ly = "Du_lieu_Luu_tru"

function Doc_du_lieu_Cua_hang()
{
    var duong_dan = Duong_dan_xu_ly + "//" + "Cua_hang.json"
    var Chuoi_json = File.readFileSync(duong_dan,"UTF-8")
    var Cua_hang= JSON.parse(Chuoi_json)
    return Cua_hang
}

function Thong_tin_dich_vu()
{
    var duong_dan = "index.html"
    var doc_file = File.readFileSync(duong_dan,"UTF-8")
    return doc_file
}

class XL_Luu_tru{
    Doc_cua_hang()
    {
        var du_lieu= {}
        du_lieu.cua_hang = Doc_du_lieu_Cua_hang()
        return du_lieu
    }

    Doc_thong_tin_DV()
    {
        return Thong_tin_dich_vu()
    }

    Ghi_cua_hang(doi_tuong)
    {
        var kq = "OK"
        try {
            var duong_dan = Duong_dan_xu_ly + "//" + "Cua_hang.json"
            var chuoi = JSON.stringify(doi_tuong,null,"\t")
            File.writeFileSync(chuoi)
        } catch (Loi) {
            kq=Loi
        }
        return kq
    }
}

var Xu_ly = new XL_Luu_tru
module.exports = Xu_ly