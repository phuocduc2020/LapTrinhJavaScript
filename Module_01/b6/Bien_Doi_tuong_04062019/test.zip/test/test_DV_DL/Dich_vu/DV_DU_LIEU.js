var NodeJS = require("http")
var getQuerystring = require("querystring")
var Port = 3500

var duong_dan_Luu_tru = require("../Xu_ly/XL_LUU_TRU")
var du_lieu = duong_dan_Luu_tru.Doc_cua_hang()

//create server
var Server = NodeJS.createServer((req,res)=>{
    var Dia_chi_tham_so =req.url.replace("/","").replace("?","")
    var tham_so = getQuerystring.parse(Dia_chi_tham_so)

    //yeu cau
    var chuoi_nhan=""
    req.on('data',(chunk)=>{chuoi_nhan += chunk})

    var chuoi_kq =""
    req.on('end',()=>{
        //quyen server
        res.setHeader("Access-Control-Allow-Origin","*")
        //xu ly chuoi
        var Xu_ly_tham_so = tham_so.Xu_ly_tham_so
        if(Xu_ly_tham_so == "Cua_hang")
        {
            chuoi_kq = JSON.stringify(du_lieu.cua_hang)
            res.end(chuoi_kq)
        }
        else if(Xu_ly_tham_so == "Ghi_Cua_hang")
        {
            var Cua_hang = JSON.parse(chuoi_nhan)
            var kq = duong_dan_Luu_tru.Ghi_cua_hang(Cua_hang)

            if(kq == "OK")
            {
                du_lieu.cua_hang=cua_hang
                chuoi_kq = JSON.stringify(cua_hang)
                
            }
            else
            {
                chuoi_kq =`xay ra loi~`
            }
            res.end(chuoi_kq)
        }
        else{
            chuoi_kq = duong_dan_Luu_tru.Doc_thong_tin_DV()
            res.end(chuoi_kq)
        }
    })
})

Server.listen(Port,console.log(`server http://localhost:${Port}`))